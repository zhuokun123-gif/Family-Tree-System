const mysql = require('mysql2/promise');

async function updateSchema() {
    const connection = await mysql.createConnection({
        host: 'localhost',
        user: 'root',
        password: '',
        database: 'family tree',
        port: 3306
    });

    try {
        console.log('Adding new columns...');
        
        await connection.execute('ALTER TABLE familytree_people ADD COLUMN IF NOT EXISTS Gender VARCHAR(20) DEFAULT "Unknown"');
        console.log('✅ Added Gender column');
        
        await connection.execute('ALTER TABLE familytree_people ADD COLUMN IF NOT EXISTS Age INT DEFAULT NULL');
        console.log('✅ Added Age column');
        
        await connection.execute('ALTER TABLE familytree_people ADD COLUMN IF NOT EXISTS Life_Status VARCHAR(20) DEFAULT "Unknown"');
        console.log('✅ Added Life_Status column');
        
        await connection.execute('ALTER TABLE familytree_people ADD COLUMN IF NOT EXISTS Marital_Status VARCHAR(20) DEFAULT "Unknown"');
        console.log('✅ Added Marital_Status column');
        
        console.log('Schema update completed!');
        
    } catch (error) {
        console.error('Error:', error.message);
    } finally {
        await connection.end();
    }
}

updateSchema();

