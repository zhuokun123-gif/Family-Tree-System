const express = require('express');
const router = express.Router();
const { pool } = require('../db');

// Enhanced Families endpoint with derived values
router.get('/', async (req, res) => {
  try {
    // Get all families data
    const [familiesRows] = await pool.query('SELECT * FROM `familytree_families`');
    
    // Get all people data to get names for Father and Mother IDs
    const [peopleRows] = await pool.query('SELECT * FROM `familytree_people`');
    
    // Create a map for quick lookup of person names by ID
    const peopleMap = new Map();
    peopleRows.forEach(person => {
      const name = `${person['Forenames'] || ''} ${person['Surname'] || ''}`.trim();
      peopleMap.set(person['Personal _ID'], name || 'Unknown');
    });
    
    // Process each family with derived values
    const enhancedFamilies = familiesRows.map(family => {
      const familyId = family['Family_ID'];
      const fatherId = family['Father ID'];
      const motherId = family['Mother_ID'];
      
      // Get Father Name
      let fatherName = 'Unknown';
      if (fatherId && fatherId.trim()) {
        fatherName = peopleMap.get(fatherId.trim()) || 'Unknown';
      }
      
      // Get Mother Name
      let motherName = 'Unknown';
      if (motherId && motherId.trim()) {
        motherName = peopleMap.get(motherId.trim()) || 'Unknown';
      }
      
      // Get Marriage Year (if available in people data)
      let marriageYear = 'Unknown';
      if (fatherId && fatherId.trim()) {
        const father = peopleRows.find(p => p['Personal _ID'] === fatherId.trim());
        if (father && father['Marriage_Year']) {
          marriageYear = father['Marriage_Year'];
        }
      }
      
      // If no marriage year from father, check mother
      if (marriageYear === 'Unknown' && motherId && motherId.trim()) {
        const mother = peopleRows.find(p => p['Personal _ID'] === motherId.trim());
        if (mother && mother['Marriage_Year']) {
          marriageYear = mother['Marriage_Year'];
        }
      }
      
      // Count children
      const children = [];
      for (let i = 1; i <= 10; i++) {
        const childId = family[`Child_ID_${i}`];
        if (childId && childId.trim()) {
          const childName = peopleMap.get(childId.trim()) || childId;
          children.push(childName);
        }
      }
      
      return {
        ...family,
        Father_Name: fatherName,
        Mother_Name: motherName,
        Marriage_Year: marriageYear,
        Children_Count: children.length,
        Children_Names: children
      };
    });
    
    res.json(enhancedFamilies);
  } catch (err) {
    console.error('Enhanced families endpoint error:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

module.exports = router;
