const express = require('express');
const router = express.Router();
const { pool } = require('../db');
const auth = require('../middleware/auth');

// Admin login
router.post('/login', async (req, res) => {
	try {
		const { username, password } = req.body;
		
		// Simple admin authentication (in production, use proper password hashing)
		if (username === 'admin' && password === '123456') {
			// Generate a simple token (in production, use JWT)
			const token = Buffer.from(`${username}:${Date.now()}`).toString('base64');
			res.json({ success: true, token, message: 'Login successful' });
		} else {
			res.status(401).json({ success: false, error: 'Invalid credentials' });
		}
	} catch (error) {
		console.error('Login error:', error);
		res.status(500).json({ success: false, error: 'Login failed' });
	}
});

// Add a new person
router.post('/people', auth, async (req, res) => {
	try {
		const {
			'Personal _ID': personalId,
			'Forenames': forenames,
			'Surname': surname,
			'Birth_Year': birthYear,
			'Death_Year': deathYear,
			'Parents_ID': parentsId,
			'Spouse_ID': spouseId,
			'Marriage_Year': marriageYear
		} = req.body;

		const query = `
			INSERT INTO familytree_people 
			(\`Personal _ID\`, \`Forenames\`, \`Surname\`, \`Birth_Year\`, \`Death_Year\`, \`Parents_ID\`, \`Spouse_ID\`, \`Marriage_Year\`)
			VALUES (?, ?, ?, ?, ?, ?, ?, ?)
		`;
		
		const [result] = await pool.execute(query, [
			personalId, forenames, surname, birthYear, deathYear, parentsId, spouseId, marriageYear
		]);

		res.json({ 
			success: true, 
			id: result.insertId, 
			message: 'Person added successfully' 
		});
	} catch (error) {
		console.error('Add person error:', error);
		res.status(500).json({ 
			success: false, 
			error: error.message || 'Failed to add person' 
		});
	}
});

// Update a person
router.put('/people/:id', auth, async (req, res) => {
	try {
		const { id } = req.params;
		const {
			'Personal _ID': personalId,
			'Forenames': forenames,
			'Surname': surname,
			'Birth_Year': birthYear,
			'Death_Year': deathYear,
			'Parents_ID': parentsId,
			'Spouse_ID': spouseId,
			'Marriage_Year': marriageYear
		} = req.body;

		const query = `
			UPDATE familytree_people 
			SET \`Forenames\` = ?, \`Surname\` = ?, \`Birth_Year\` = ?, \`Death_Year\` = ?, 
				\`Parents_ID\` = ?, \`Spouse_ID\` = ?, \`Marriage_Year\` = ?
			WHERE \`Personal _ID\` = ?
		`;
		
		const [result] = await pool.execute(query, [
			forenames, surname, birthYear, deathYear, parentsId, spouseId, marriageYear, id
		]);

		if (result.affectedRows === 0) {
			return res.status(404).json({ 
				success: false, 
				error: 'Person not found' 
			});
		}

		res.json({ 
			success: true, 
			message: 'Person updated successfully' 
		});
	} catch (error) {
		console.error('Update person error:', error);
		res.status(500).json({ 
			success: false, 
			error: error.message || 'Failed to update person' 
		});
	}
});

// Delete a person
router.delete('/people/:id', auth, async (req, res) => {
	try {
		const { id } = req.params;

		const query = 'DELETE FROM familytree_people WHERE `Personal _ID` = ?';
		const [result] = await pool.execute(query, [id]);

		if (result.affectedRows === 0) {
			return res.status(404).json({ 
				success: false, 
				error: 'Person not found' 
			});
		}

		res.json({ 
			success: true, 
			message: 'Person deleted successfully' 
		});
	} catch (error) {
		console.error('Delete person error:', error);
		res.status(500).json({ 
			success: false, 
			error: error.message || 'Failed to delete person' 
		});
	}
});

// Add a new family
router.post('/families', auth, async (req, res) => {
	try {
		const {
			'Family_ID': familyId,
			'Father_ID': fatherId,
			'Mother_ID': motherId,
			'Child_ID_1': childId1,
			'Child_ID_2': childId2,
			'Child_ID_3': childId3
		} = req.body;

		const query = `
			INSERT INTO familytree_families 
			(\`Family_ID\`, \`Father_ID\`, \`Mother_ID\`, \`Child_ID_1\`, \`Child_ID_2\`, \`Child_ID_3\`)
			VALUES (?, ?, ?, ?, ?, ?)
		`;
		
		const [result] = await pool.execute(query, [
			familyId, fatherId, motherId, childId1, childId2, childId3
		]);

		res.json({ 
			success: true, 
			id: result.insertId, 
			message: 'Family added successfully' 
		});
	} catch (error) {
		console.error('Add family error:', error);
		res.status(500).json({ 
			success: false, 
			error: error.message || 'Failed to add family' 
		});
	}
});

// Update a family
router.put('/families/:id', auth, async (req, res) => {
	try {
		const { id } = req.params;
		const {
			'Family_ID': familyId,
			'Father_ID': fatherId,
			'Mother_ID': motherId,
			'Child_ID_1': childId1,
			'Child_ID_2': childId2,
			'Child_ID_3': childId3
		} = req.body;

		const query = `
			UPDATE familytree_families 
			SET \`Father_ID\` = ?, \`Mother_ID\` = ?, \`Child_ID_1\` = ?, \`Child_ID_2\` = ?, \`Child_ID_3\` = ?
			WHERE \`Family_ID\` = ?
		`;
		
		const [result] = await pool.execute(query, [
			fatherId, motherId, childId1, childId2, childId3, id
		]);

		if (result.affectedRows === 0) {
			return res.status(404).json({ 
				success: false, 
				error: 'Family not found' 
			});
		}

		res.json({ 
			success: true, 
			message: 'Family updated successfully' 
		});
	} catch (error) {
		console.error('Update family error:', error);
		res.status(500).json({ 
			success: false, 
			error: error.message || 'Failed to update family' 
		});
	}
});

// Delete a family
router.delete('/families/:id', auth, async (req, res) => {
	try {
		const { id } = req.params;

		const query = 'DELETE FROM familytree_families WHERE `Family_ID` = ?';
		const [result] = await pool.execute(query, [id]);

		if (result.affectedRows === 0) {
			return res.status(404).json({ 
				success: false, 
				error: 'Family not found' 
			});
		}

		res.json({ 
			success: true, 
			message: 'Family deleted successfully' 
		});
	} catch (error) {
		console.error('Delete family error:', error);
		res.status(500).json({ 
			success: false, 
			error: error.message || 'Failed to delete family' 
		});
	}
});

module.exports = router;


