const express = require('express');
const router = express.Router();
const { pool } = require('../db');

// Enhanced People endpoint with derived values
router.get('/', async (req, res) => {
  try {
    // Get all people data
    const [peopleRows] = await pool.query('SELECT * FROM `familytree_people`');
    
    // Get all families data to determine gender relationships
    const [familiesRows] = await pool.query('SELECT * FROM `familytree_families`');
    
    // Create sets for quick lookup of father and mother IDs
    const fatherIds = new Set();
    const motherIds = new Set();
    
    familiesRows.forEach(family => {
      if (family['Father ID'] && family['Father ID'].trim()) {
        fatherIds.add(family['Father ID'].trim());
      }
      if (family['Mother_ID'] && family['Mother_ID'].trim()) {
        motherIds.add(family['Mother_ID'].trim());
      }
    });
    
    // Process each person with derived values
    const enhancedPeople = peopleRows.map(person => {
      const personId = person['Personal _ID'];
      
      // Rule 1: Determine Gender
      let gender = 'Unknown';
      if (fatherIds.has(personId)) {
        gender = 'Male';
      } else if (motherIds.has(personId)) {
        gender = 'Female';
      }
      
      // Rule 2: Calculate Age and Status
      let age = 'Unknown';
      let status = 'Unknown';
      const birthYear = person['Birth_Year'] ? parseInt(person['Birth_Year']) : null;
      const deathYear = person['Death_Year'] ? parseInt(person['Death_Year']) : null;
      
      if (birthYear && deathYear && !isNaN(birthYear) && !isNaN(deathYear)) {
        age = deathYear - birthYear;
        status = 'Deceased';
      } else if (birthYear && !isNaN(birthYear)) {
        // If only birth year is available, estimate if likely deceased
        const currentYear = new Date().getFullYear();
        const estimatedAge = currentYear - birthYear;
        if (estimatedAge > 130) {
          status = 'Deceased';
          age = 'Unknown';
        } else {
          status = 'Living';
          age = 'Unknown';
        }
      }
      
      // Rule 3: Determine Marital Status
      let maritalStatus = 'Single';
      if (person['Spouse_ID'] && person['Spouse_ID'].trim()) {
        maritalStatus = 'Married';
      }
      
      return {
        ...person,
        Gender: gender,
        Age: age,
        Status: status,
        Marital_Status: maritalStatus
      };
    });
    
    res.json(enhancedPeople);
  } catch (err) {
    console.error('Enhanced people endpoint error:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

module.exports = router;
