Family Tree Backend (Node.js + Express + MySQL)

Environment variables (create a .env file):

PORT=3000
CORS_ORIGIN=http://localhost:5173
JWT_SECRET=change-this-secret
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=
DB_NAME=family tree
ADMIN_USER=admin
ADMIN_PASS=123456

Scripts:
- npm run dev
- npm start

APIs:
- GET /api/people
- GET /api/families
- GET /api/person/:id
- POST /api/admin/login
- POST /api/admin/people (Bearer token required)
- POST /api/admin/families (Bearer token required)


