<template>
  <div class="ef-container">
    <!-- Left: Visualization Area -->
    <section class="viz-panel">
      <header class="viz-header">
        <div class="title">Family Tree Visualization</div>
        <div class="controls">
          <input class="search" v-model="searchQuery" placeholder="Search by name or ID" @keyup.enter="handleSearch" />

          <div class="control-group">
            <button @click="fitToView" title="Fit to view" class="icon-btn">🔎</button>
            <button @click="resetView" title="Reset view" class="icon-btn">🔄</button>
            <button @click="toggleGrid" title="Toggle grid" class="icon-btn">▦</button>
            <button @click="exportPNG" title="Export PNG" class="icon-btn">⬇️</button>
          </div>

          <div class="zoom-control">
            <input type="range" min="10" max="300" v-model.number="zoomPercent" @input="onZoomRange" />
            <div class="zoom-label">{{ Math.round(zoomPercent) }}%</div>
          </div>
        </div>
      </header>

      <div class="viz-body" ref="viz">
        <canvas ref="canvas" class="main-canvas" aria-label="Family tree canvas"></canvas>

        <!-- Minimap (click to center) -->
        <canvas ref="minimap" class="minimap" @click="onMinimapClick" aria-hidden="true"></canvas>

        <!-- Floating legend / hints -->
        <div class="legend">
          <div class="legend-row"><span class="chip male"></span> Male</div>
          <div class="legend-row"><span class="chip female"></span> Female</div>
          <div class="legend-row"><span class="chip unknown"></span> Unknown</div>
          <div class="legend-row"><span class="chip alive"></span> Living</div>
          <div class="legend-row"><span class="chip deceased"></span> Deceased</div>
        </div>

        <!-- Empty / loading overlay inside viz panel -->
        <div v-if="loading" class="viz-overlay">Loading tree...</div>
        <div v-if="errorMessage" class="viz-overlay error">{{ errorMessage }}</div>
      </div>

      <footer class="viz-footer">
        <div class="status">Canvas: {{ canvasSize.width }} × {{ canvasSize.height }} • DPR: {{ devicePixelRatio }}</div>
        <div class="help">Drag to pan • Scroll to zoom • Double-click node to center</div>
      </footer>
    </section>

    <!-- Right: Relationship / Info Panel (keeps the function) -->
    <aside class="info-panel">
      <div class="info-header">
        <h3>Family Relationships</h3>
        <div class="info-actions">
          <button @click="emit({ name: 'export', payload: treeData })" title="Emit export">Export</button>
        </div>
      </div>

      <div class="info-body">
        <!-- Person Summary -->
        <section class="person-summary" v-if="treeData.person">
          <div class="person-row">
            <div class="avatar" :data-gender="getPersonGender(treeData.person)">{{ getInitials(treeData.person.fullName) }}</div>
            <div class="meta">
              <div class="name">{{ treeData.person.fullName }}</div>
              <div class="sub">ID: <span class="muted">{{ treeData.person.personalId }}</span></div>
            </div>
          </div>

          <dl class="person-stats">
            <div><dt>Gender</dt><dd>{{ getGenderDisplay(treeData.person) }}</dd></div>
            <div><dt>Years</dt><dd>{{ getYearsDisplay(treeData.person) }}</dd></div>
            <div><dt>Status</dt><dd :class="getStatusClass(treeData.person)">{{ getStatusDisplay(treeData.person) }}</dd></div>
            <div><dt>Generation</dt><dd>{{ treeData.person.generation || 'Not Available' }}</dd></div>
            <div><dt>Marriage Year</dt><dd>{{ getMarriageYearDisplay(treeData.person) }}</dd></div>
          </dl>
        </section>

        <!-- Relatives grouped similarly to original UI but tidier -->
        <section class="relatives" v-if="treeData.relativesByType">
          <template v-for="(group, label) in simplifiedGroups" :key="label">
            <div v-if="treeData.relativesByType[group]?.length" class="group">
              <h4>{{ label }}</h4>
              <ul>
                <li v-for="member in treeData.relativesByType[group]" :key="member.member.personalId" @dblclick="centerOn(member.member.personalId)">
                  <div class="member-name">{{ member.member.fullName }}</div>
                  <div class="member-meta">{{ member.relationship }} • {{ member.member.birthDeathYears || getYearsDisplay(member.member) }}</div>
                </li>
              </ul>
            </div>
          </template>
        </section>

        <!-- Tree stats -->
        <section class="tree-stats" v-if="treeData.treeStats">
          <h4>Tree Statistics</h4>
          <div class="stats-grid">
            <div class="stat"><div class="num">{{ treeData.treeStats.totalMembers }}</div><div class="label">Total</div></div>
            <div class="stat"><div class="num alive">{{ treeData.treeStats.livingMembers }}</div><div class="label">Living</div></div>
            <div class="stat"><div class="num deceased">{{ treeData.treeStats.deceasedMembers }}</div><div class="label">Deceased</div></div>
            <div class="stat"><div class="num">{{ treeData.treeStats.totalGenerations }}</div><div class="label">Generations</div></div>
            <div class="stat"><div class="num birthday">{{ treeData.treeStats.birthdayMembers }}</div><div class="label">Birthdays Today</div></div>
          </div>
        </section>
      </div>
    </aside>
  </div>
</template>

<script setup>
import { ref, onMounted, onBeforeUnmount, watch, reactive } from 'vue'
import axios from 'axios'

const props = defineProps({ rootId: { type: [String, Number], required: true } })
const emit = defineEmits(['select', 'export'])

// Refs & state
const viz = ref(null)
const canvas = ref(null)
const minimap = ref(null)
const loading = ref(false)
const errorMessage = ref('')
const treeData = ref({})

const canvasSize = reactive({ width: 0, height: 0 })
let ctx = null
let minimapCtx = null
let resizeObserver = null

// Interaction state
const devicePixelRatio = window.devicePixelRatio || 1
const zoom = ref(1)
const zoomPercent = ref(100)
const panX = ref(0)
const panY = ref(0)
const isDragging = ref(false)
const lastMouse = reactive({ x: 0, y: 0 })
const showGrid = ref(true)
const searchQuery = ref('')

// simplified group mapping for right panel display order
const simplifiedGroups = {
  'Parents': 'parents',
  'Spouses': 'spouses',
  'Children': 'children',
  'Siblings': 'siblings',
  'Grandparents': 'grandparents',
  'Uncles': 'uncles',
  'Aunts': 'aunts',
  'Cousins': 'cousins',
  'Nephews & Nieces': 'nephews'
}

function ensureCanvasSize() {
  if (!canvas.value || !viz.value) return
  const rect = viz.value.getBoundingClientRect()
  const w = Math.max(400, Math.floor(rect.width))
  const h = Math.max(360, Math.floor(rect.height))
  canvas.value.style.width = w + 'px'
  canvas.value.style.height = h + 'px'
  canvas.value.width = Math.round(w * devicePixelRatio)
  canvas.value.height = Math.round(h * devicePixelRatio)
  canvasSize.width = w
  canvasSize.height = h

  // set or reset ctx
  ctx = canvas.value.getContext('2d')
  ctx.setTransform(devicePixelRatio, 0, 0, devicePixelRatio, 0, 0) // normalize scaling

  // minimap
  if (minimap.value) {
    const mw = 220
    const mh = Math.round((h / w) * mw)
    minimap.value.width = mw * devicePixelRatio
    minimap.value.height = mh * devicePixelRatio
    minimap.value.style.width = mw + 'px'
    minimap.value.style.height = mh + 'px'
    minimapCtx = minimap.value.getContext('2d')
    minimapCtx.setTransform(devicePixelRatio, 0, 0, devicePixelRatio, 0, 0)
  }
}

async function loadEnhancedTree() {
  if (!props.rootId) return
  loading.value = true
  errorMessage.value = ''
  try {
    const { data } = await axios.get(`/api/enhanced-tree/person/${encodeURIComponent(props.rootId)}`)
    if (!data || !data.person) throw new Error('Person not found')
    treeData.value = data
    emit('select', data)
    // small delay ensures size calculations are ready
    setTimeout(() => renderEnhancedTree(data), 80)
  } catch (e) {
    errorMessage.value = e?.response?.data?.error || e?.message || 'Failed to load'
  } finally {
    loading.value = false
  }
}

function clearCanvas() {
  if (!ctx) return
  ctx.save()
  ctx.setTransform(1,0,0,1,0,0)
  ctx.clearRect(0,0,canvas.value.width,canvas.value.height)
  ctx.restore()
}

function renderEnhancedTree(data) {
  if (!canvas.value || !ctx || !data || !data.person) return
  const w = canvasSize.width
  const h = canvasSize.height
  clearCanvas()

  // Background
  ctx.fillStyle = '#fafafa'
  ctx.fillRect(0,0,w,h)

  ctx.save()
  // Apply pan & zoom
  ctx.translate(panX.value, panY.value)
  ctx.scale(zoom.value, zoom.value)

  // Optionally draw grid
  if (showGrid.value) drawGrid(ctx, w, h)

  // draw center person big and others around — reuse helper functions from your original implementation
  // For readability and maintainability this file contains modernized, simplified drawing logic
  drawCentralTree(ctx, data, w, h)

  ctx.restore()

  // Update minimap (cheap copy)
  updateMinimap()
}

function drawGrid(ctx, w, h) {
  ctx.save()
  ctx.strokeStyle = '#eef2f7'
  ctx.lineWidth = 1
  for (let x = 0; x < w; x += 40) { ctx.beginPath(); ctx.moveTo(x,0); ctx.lineTo(x,h); ctx.stroke() }
  for (let y = 0; y < h; y += 40) { ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(w,y); ctx.stroke() }
  ctx.restore()
}

function drawCentralTree(ctx, data, w, h) {
  // A compact, visually pleasant layout based on your earlier logic but trimmed for readability
  // Node sizing and spacing
  const nodeW = 160
  const nodeH = 56
  const genSpacing = 140
  const colSpacing = 180

  const centerX = w / 2
  const centerY = h / 2

  // Root
  const rootX = centerX - colSpacing/2
  const rootY = centerY
  drawNode(ctx, rootX, rootY, data.person, 'root', nodeW, nodeH)

  // spouse
  if (data.relativesByType?.spouses?.length) {
    const spouse = data.relativesByType.spouses[0].member
    const spouseX = centerX + colSpacing/2
    const spouseY = centerY
    drawNode(ctx, spouseX, spouseY, spouse, 'spouse', nodeW, nodeH)
    drawMarriageLine(ctx, rootX + nodeW/2, rootY + nodeH/2, spouseX - nodeW/2, spouseY + nodeH/2)
  }

  // parents
  if (data.relativesByType?.parents?.length) {
    const parents = data.relativesByType.parents
    const py = centerY - genSpacing
    parents.forEach((p, i) => {
      const px = rootX + (i - (parents.length - 1)/2) * colSpacing
      drawNode(ctx, px, py, p.member, 'parent', nodeW, nodeH)
      drawParentChild(ctx, px, py + nodeH, rootX + nodeW/2, rootY)
    })
  }

  // children
  if (data.relativesByType?.children?.length) {
    const kids = data.relativesByType.children
    const cy = centerY + genSpacing
    kids.forEach((k, i) => {
      const cx = centerX + (i - (kids.length - 1)/2) * colSpacing
      drawNode(ctx, cx, cy, k.member, 'child', nodeW, nodeH)
      drawParentChild(ctx, rootX + nodeW/2, rootY + nodeH, cx + nodeW/2, cy)
    })
  }
}

function drawNode(ctx, x, y, person, type, w, h) {
  const gender = getPersonGender(person)
  let fill = '#ffffff', stroke = '#cbd5e1', text = '#111827'
  if (gender === 'Male') { fill = '#e6f0ff'; stroke = '#3b82f6'; text = '#0f172a' }
  if (gender === 'Female') { fill = '#fff0f6'; stroke = '#db2777'; text = '#3f0b26' }
  if (getStatusDisplay(person) === 'Deceased') { fill = '#f8fafc'; stroke = '#94a3b8' }

  ctx.save()
  ctx.beginPath()
  roundRect(ctx, x - w/2, y - h/2, w, h, 8)
  ctx.fillStyle = fill
  ctx.fill()
  ctx.lineWidth = type === 'root' ? 3 : 1.5
  ctx.strokeStyle = type === 'root' ? '#ff6b2d' : stroke
  ctx.stroke()

  // name
  ctx.fillStyle = text
  ctx.font = 'bold 12px Inter, Arial'
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  const name = person.fullName || person.personalId || '—'
  ctx.fillText(truncateName(name, 28), x, y - 6)
  ctx.font = '11px Inter, Arial'
  ctx.fillStyle = '#6b7280'
  ctx.fillText(person.personalId || '', x, y + 12)
  ctx.restore()
}

function roundRect(ctx, x, y, w, h, r) {
  ctx.moveTo(x + r, y)
  ctx.arcTo(x + w, y, x + w, y + h, r)
  ctx.arcTo(x + w, y + h, x, y + h, r)
  ctx.arcTo(x, y + h, x, y, r)
  ctx.arcTo(x, y, x + w, y, r)
  ctx.closePath()
}

function truncateName(name, max) {
  if (!name) return ''
  if (name.length <= max) return name
  return name.slice(0, max - 1) + '…'
}

function drawMarriageLine(ctx, x1, y1, x2, y2) {
  ctx.save()
  ctx.beginPath()
  ctx.setLineDash([6,6])
  ctx.strokeStyle = '#ef4444'
  ctx.lineWidth = 2
  ctx.moveTo(x1, y1)
  ctx.lineTo(x2, y2)
  ctx.stroke()
  ctx.setLineDash([])
  ctx.fillStyle = '#ef4444'
  ctx.font = '12px Arial'
  ctx.textAlign = 'center'
  ctx.fillText('♥', (x1 + x2)/2, (y1 + y2)/2 - 6)
  ctx.restore()
}

function drawParentChild(ctx, x1, y1, x2, y2) {
  ctx.save()
  ctx.beginPath()
  const midY = (y1 + y2) / 2
  ctx.moveTo(x1, y1)
  ctx.bezierCurveTo(x1, midY, x2, midY, x2, y2)
  ctx.strokeStyle = '#0ea5a4'
  ctx.lineWidth = 2
  ctx.stroke()
  ctx.restore()
}

function updateMinimap() {
  if (!minimapCtx || !canvas.value) return
  const mw = minimap.value.clientWidth
  const mh = minimap.value.clientHeight
  minimapCtx.clearRect(0,0,mw,mh)
  try { minimapCtx.drawImage(canvas.value, 0,0, canvasSize.width, canvasSize.height, 0,0, mw, mh) } catch(e) {}
  // draw viewport rectangle
  minimapCtx.strokeStyle = 'rgba(0,0,0,0.25)'
  minimapCtx.lineWidth = 1
  const viewW = mw / zoom.value
  const viewH = mh / zoom.value
  const viewX = -panX.value / (canvasSize.width) * mw
  const viewY = -panY.value / (canvasSize.height) * mh
  minimapCtx.strokeRect(viewX, viewY, viewW, viewH)
}

// Interaction handlers
function handleMouseDown(e) { isDragging.value = true; lastMouse.x = e.clientX; lastMouse.y = e.clientY; canvas.value.style.cursor = 'grabbing' }
function handleMouseMove(e) {
  if (!isDragging.value) return
  const dx = e.clientX - lastMouse.x; const dy = e.clientY - lastMouse.y
  panX.value += dx; panY.value += dy
  lastMouse.x = e.clientX; lastMouse.y = e.clientY
  renderEnhancedTree(treeData.value)
}
function handleMouseUp() { isDragging.value = false; canvas.value.style.cursor = 'grab' }

function handleWheel(e) {
  e.preventDefault()
  const rect = canvas.value.getBoundingClientRect()
  const mx = e.clientX - rect.left
  const my = e.clientY - rect.top
  const delta = e.deltaY > 0 ? 0.9 : 1.1
  const newZoom = Math.max(0.1, Math.min(3, zoom.value * delta))
  const factor = newZoom / zoom.value
  panX.value = mx - (mx - panX.value) * factor
  panY.value = my - (my - panY.value) * factor
  zoom.value = newZoom
  zoomPercent.value = zoom.value * 100
  renderEnhancedTree(treeData.value)
}

function resetView() { zoom.value = 1; zoomPercent.value = 100; panX.value = 0; panY.value = 0; renderEnhancedTree(treeData.value) }
function fitToView() { /* simple heuristic: center and reset zoom */ resetView() }
function onZoomRange() { zoom.value = Math.max(0.1, zoomPercent.value / 100); renderEnhancedTree(treeData.value) }

function toggleGrid() { showGrid.value = !showGrid.value; renderEnhancedTree(treeData.value) }

function exportPNG() {
  if (!canvas.value) return
  const scale = devicePixelRatio
  const link = document.createElement('a')
  link.download = `family-tree-${treeData.value.person?.personalId || 'export'}.png`
  link.href = canvas.value.toDataURL('image/png')
  link.click()
}

function getPersonGender(person) { return person?.gender || person?.Gender || 'Unknown' }
function getGenderDisplay(person) { return person?.gender || 'Unknown' }
function getYearsDisplay(person) { const birth = person?.birthYear || person?.Birth_Year; const death = person?.deathYear || person?.Death_Year; return birth ? `${birth} - ${death || 'Not Recorded'}` : 'Not Recorded' }
function getStatusDisplay(person) { if (person?.lifeStatus) return person.lifeStatus; if (person?.isAlive !== undefined) return person.isAlive ? 'Living' : 'Deceased'; const death = person?.deathYear || person?.Death_Year; if (death) return 'Deceased'; const birth = person?.birthYear || person?.Birth_Year; if (birth && birth < 1900) return 'Deceased'; return 'Unknown' }
function getStatusClass(person) { return getStatusDisplay(person).toLowerCase() === 'living' ? 'alive' : 'deceased' }
function getMarriageYearDisplay(person) { return person?.marriageYear || person?.Marriage_Year || 'Not Recorded' }

function getInitials(name) { if (!name) return '—'; return name.split(' ').map(s => s[0]).slice(0,2).join('').toUpperCase() }

function centerOn(personId) {
  // best-effort: find coordinates in current treeData (if positions available) — otherwise reset focus
  // In a more advanced implementation you'll maintain nodePositions; here we simply reset and highlight
  resetView()
}

function onMinimapClick(e) {
  if (!minimap.value) return
  const rect = minimap.value.getBoundingClientRect()
  const x = e.clientX - rect.left
  const y = e.clientY - rect.top
  // map to pan coordinates (quick heuristic)
  panX.value = - (x / minimap.value.clientWidth) * canvasSize.width + canvasSize.width/2
  panY.value = - (y / minimap.value.clientHeight) * canvasSize.height + canvasSize.height/2
  renderEnhancedTree(treeData.value)
}

function handleSearch() {
  if (!searchQuery.value) return
  // simple search in treeData for a match - if found, center (best effort)
  const q = searchQuery.value.toLowerCase()
  const groups = treeData.value.relativesByType || {}
  let found = null
  for (const k in groups) {
    for (const m of groups[k]) {
      if ((m.member.fullName || '').toLowerCase().includes(q) || (m.member.personalId || '').toLowerCase().includes(q)) {
        found = m.member
        break
      }
    }
    if (found) break
  }
  if (found) {
    // simple UX: show in right panel and nudge view
    // In full implementation you would compute node positions and center precisely
    alert(`Found: ${found.fullName} — centering (approx)`)
    resetView()
  } else {
    alert('No match found')
  }
}

onMounted(() => {
  // wait a tick for layout
  setTimeout(() => {
    if (viz.value) {
      resizeObserver = new ResizeObserver(() => { ensureCanvasSize(); renderEnhancedTree(treeData.value) })
      resizeObserver.observe(viz.value)
    }

    if (canvas.value) {
      canvas.value.addEventListener('mousedown', handleMouseDown)
      window.addEventListener('mousemove', handleMouseMove)
      window.addEventListener('mouseup', handleMouseUp)
      canvas.value.addEventListener('wheel', handleWheel, { passive: false })
      canvas.value.style.cursor = 'grab'
    }

    ensureCanvasSize()
    loadEnhancedTree()
  }, 60)
})

watch(() => props.rootId, () => loadEnhancedTree())

onBeforeUnmount(() => {
  if (resizeObserver && viz.value) resizeObserver.unobserve(viz.value)
  if (canvas.value) {
    canvas.value.removeEventListener('mousedown', handleMouseDown)
    canvas.value.removeEventListener('wheel', handleWheel)
  }
})
</script>

<style scoped>
/* Layout */
.ef-container { display: grid; grid-template-columns: 1fr 360px; gap: 18px; height: 100%; padding: 12px }
.viz-panel { display: flex; flex-direction: column; background: linear-gradient(180deg,#ffffff,#fbfdff); border-radius: 12px; box-shadow: 0 6px 22px rgba(15,23,42,0.06); overflow: hidden; border: 1px solid #e6eef7 }
.viz-header { display:flex; align-items:center; justify-content:space-between; padding: 12px 16px; border-bottom: 1px solid #eef2f7 }
.viz-header .title { font-weight:700; color:#0f172a }
.controls { display:flex; align-items:center; gap:12px }
.controls .search { padding:8px 10px; border-radius:8px; border:1px solid #e6eef7; min-width:260px }
.icon-btn { background:#fff; border:1px solid #e6eef7; padding:8px 10px; border-radius:8px; cursor:pointer; box-shadow:0 2px 6px rgba(2,6,23,0.04) }
.icon-btn:hover { transform:translateY(-1px) }
.zoom-control { display:flex; align-items:center; gap:8px }
.zoom-control input[type=range] { width:120px }
.zoom-label { min-width:40px; text-align:center }

.viz-body { position:relative; flex:1; min-height:420px; display:flex; align-items:stretch }
.main-canvas { width:100%; height:100%; display:block; background:transparent }

.minimap { position:absolute; right:12px; bottom:12px; width:220px; height:120px; border-radius:8px; box-shadow:0 6px 18px rgba(2,6,23,0.12); border:1px solid rgba(15,23,42,0.06); background:#fff }
.legend { position:absolute; left:12px; bottom:12px; background:rgba(255,255,255,0.9); border-radius:8px; padding:8px 10px; box-shadow:0 6px 18px rgba(2,6,23,0.06); border:1px solid #eef2f7 }
.legend-row { display:flex; align-items:center; gap:8px; font-size:13px; color:#374151 }
.chip { display:inline-block; width:12px; height:12px; border-radius:3px }
.chip.male { background:#dbeafe }
.chip.female { background:#fff0f6 }
.chip.unknown { background:#f3f4f6 }
.chip.alive { background:#ecfdf5 }
.chip.deceased { background:#f8fafc }

.viz-overlay { position:absolute; inset:0; display:flex; align-items:center; justify-content:center; font-weight:600; background:rgba(255,255,255,0.85); z-index:3 }
.viz-overlay.error { color:#b91c1c }

.viz-footer { padding:8px 12px; border-top:1px solid #eef2f7; display:flex; justify-content:space-between; align-items:center; font-size:13px; color:#475569 }

/* Info panel */
.info-panel { background:#fff; border-radius:12px; border:1px solid #e6eef7; display:flex; flex-direction:column; overflow:hidden }
.info-header { display:flex; align-items:center; justify-content:space-between; padding:12px 14px; border-bottom:1px solid #eef2f7 }
.info-header h3 { margin:0 }
.info-body { padding:12px 14px; overflow:auto }
.person-summary { background:#fbfdff; border-radius:8px; padding:10px; margin-bottom:12px; border:1px solid #eef2f7 }
.person-row { display:flex; gap:12px; align-items:center }
.avatar { width:56px; height:56px; border-radius:8px; display:flex; align-items:center; justify-content:center; font-weight:700; font-size:18px; color:#0f172a }
.avatar[data-gender='Male'] { background:linear-gradient(135deg,#e6f0ff,#dbeafe) }
.avatar[data-gender='Female'] { background:linear-gradient(135deg,#fff0f6,#ffe6f0) }
.avatar[data-gender='Unknown'] { background:#eef2f7 }
.meta .name { font-weight:700 }
.meta .sub { color:#6b7280; font-size:13px }
.person-stats { display:grid; grid-template-columns:1fr 1fr; gap:8px; margin-top:10px }
.person-stats dt { font-weight:700; font-size:12px }
.person-stats dd { margin:0; color:#374151 }

.relatives .group { margin-bottom:14px }
.relatives h4 { margin:0 0 8px 0; font-size:14px; color:#0f172a }
.relatives ul { list-style:none; padding:0; margin:0 }
.relatives li { padding:8px; border-radius:8px; display:flex; justify-content:space-between; align-items:center; gap:8px; border:1px solid #f1f5f9; margin-bottom:8px; cursor:pointer }
.relatives li:hover { background:#fbfdff }
.member-meta { color:#6b7280; font-size:12px }

.tree-stats { margin-top:10px }
.stats-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:8px }
.stat { background:#f8fbff; border-radius:6px; padding:8px; text-align:center; border:1px solid #eef2f7 }
.stat .num { font-weight:800; font-size:16px }
.stat .label { color:#6b7280; font-size:12px }
.stat .num.alive { color:#059669 }
.stat .num.deceased { color:#dc2626 }
.stat .num.birthday { color:#7c3aed }

/* small screens */
@media (max-width: 980px) {
  .ef-container { grid-template-columns: 1fr; grid-template-rows: 1fr 420px }
  .info-panel { order:2 }
}
</style>
