const auth = (req, res, next) => {
	try {
		const authHeader = req.headers.authorization;
		
		if (!authHeader || !authHeader.startsWith('Bearer ')) {
			return res.status(401).json({ 
				success: false, 
				error: 'Access token required' 
			});
		}
		
		const token = authHeader.substring(7); // Remove 'Bearer ' prefix
		
		// Simple token validation (in production, use proper JWT validation)
		if (!token || token.length < 10) {
			return res.status(401).json({ 
				success: false, 
				error: 'Invalid token' 
			});
		}
		
		// For now, just check if token exists and has minimum length
		// In production, you would decode and validate the JWT token
		req.user = { role: 'admin' }; // Set user context
		next();
		
	} catch (error) {
		console.error('Auth middleware error:', error);
		return res.status(401).json({ 
			success: false, 
			error: 'Authentication failed' 
		});
	}
};

module.exports = auth;


