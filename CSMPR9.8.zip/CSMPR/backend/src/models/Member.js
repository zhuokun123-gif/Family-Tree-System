class Member {
    constructor(data) {
        this.personalId = data['Personal _ID'] || '';
        this.forenames = data['Forenames'] || '';
        this.surname = data['Surname'] || '';
        this.birthYear = data['Birth_Year'] || null;
        this.deathYear = data['Death_Year'] || null;
        this.parentsFamilyId = data['Parents_ID'] || null;
        this.spouseFamilyId = data['Spouse_ID'] || null;
        this.marriageYear = data['Marriage_Year'] || null;
        this.gender = data['Gender'] || 'Unknown';
        this.generation = 0;
        this.childrenIds = [];
        this.spouseIds = [];
        
        // New fields from processed data
        this.age = data['Age'] || null;
        this.lifeStatus = data['Life_Status'] || 'Unknown';
        this.maritalStatus = data['Marital_Status'] || 'Unknown';
        
        // Calculate if alive
        this.isAlive = !this.deathYear;
    }

    get fullName() {
        return `${this.forenames} ${this.surname}`.trim();
    }

    get displayName() {
        return this.fullName || `ID: ${this.personalId}`;
    }

    get birthDeathYears() {
        if (!this.birthYear) return 'Unknown';
        if (this.isAlive) {
            return `${this.birthYear} - Present`;
        }
        return `${this.birthYear} - ${this.deathYear}`;
    }

    isBirthdayToday() {
        if (!this.birthYear) return false;
        const today = new Date();
        return today.getFullYear() === this.birthYear;
    }

    addChild(childId) {
        if (!this.childrenIds.includes(childId)) {
            this.childrenIds.push(childId);
        }
    }

    addSpouse(spouseId) {
        if (!this.spouseIds.includes(spouseId)) {
            this.spouseIds.push(spouseId);
        }
    }

    removeChild(childId) {
        const index = this.childrenIds.indexOf(childId);
        if (index > -1) {
            this.childrenIds.splice(index, 1);
        }
    }

    removeSpouse(spouseId) {
        const index = this.spouseIds.indexOf(spouseId);
        if (index > -1) {
            this.spouseIds.splice(index, 1);
        }
    }

    setGeneration(gen) {
        this.generation = gen;
    }

    toJSON() {
        return {
            personalId: this.personalId,
            forenames: this.forenames,
            surname: this.surname,
            birthYear: this.birthYear,
            deathYear: this.deathYear,
            parentsFamilyId: this.parentsFamilyId,
            spouseFamilyId: this.spouseFamilyId,
            marriageYear: this.marriageYear,
            gender: this.gender,
            generation: this.generation,
            childrenIds: this.childrenIds,
            spouseIds: this.spouseIds,
            isAlive: this.isAlive,
            fullName: this.fullName,
            birthDeathYears: this.birthDeathYears,
            // New fields from processed data
            age: this.age,
            lifeStatus: this.lifeStatus,
            maritalStatus: this.maritalStatus
        };
    }
}

module.exports = Member;
