const mysql = require('mysql2/promise');
const dotenv = require('dotenv');

dotenv.config({ path: '../.env' });

const dbConfig = {
  host: process.env.DB_HOST || 'localhost',
  port: process.env.DB_PORT ? Number(process.env.DB_PORT) : 3306,
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'family tree',
};

async function updateDerivedValues() {
  let conn;
  try {
    conn = await mysql.createConnection(dbConfig);
    console.log('🔗 Connected to database');
    
    // Get all people and families data
    console.log('📊 Fetching people and families data...');
    const [people] = await conn.execute('SELECT * FROM familytree_people');
    const [families] = await conn.execute('SELECT * FROM familytree_families');
    
    console.log(`📋 Found ${people.length} people and ${families.length} families`);
    
    // Create lookup maps for efficient processing
    const fatherIds = new Set(families.map(f => f.Father_ID).filter(Boolean));
    const motherIds = new Set(families.map(f => f.Mother_ID).filter(Boolean));
    const peopleMap = new Map(people.map(p => [p['Personal _ID'], p]));
    
    console.log('🔄 Processing people data...');
    
    let updatedCount = 0;
    const updates = [];
    
    for (const person of people) {
      const personId = person['Personal _ID'];
      const birthYear = person['Birth_Year'];
      const deathYear = person['Death_Year'];
      const spouseId = person['Spouse_ID'];
      
      // Derive Gender
      let gender = 'Unknown';
      if (fatherIds.has(personId)) {
        gender = 'Male';
      } else if (motherIds.has(personId)) {
        gender = 'Female';
      }
      
      // Calculate Age and Life Status
      let age = null;
      let lifeStatus = 'Unknown';
      
      if (birthYear && deathYear) {
        age = deathYear - birthYear;
        lifeStatus = age > 130 ? 'Deceased' : 'Living';
      }
      
      // Derive Marital Status
      const maritalStatus = spouseId ? 'Married' : 'Single';
      
      // Check if update is needed
      const needsUpdate = 
        person.Gender !== gender ||
        person.Age !== age ||
        person.Life_Status !== lifeStatus ||
        person.Marital_Status !== maritalStatus;
      
      if (needsUpdate) {
        updates.push({
          personId,
          gender,
          age,
          lifeStatus,
          maritalStatus
        });
        updatedCount++;
      }
    }
    
    console.log(`📝 Found ${updatedCount} people that need updates`);
    
    // Update people in batches
    if (updates.length > 0) {
      console.log('💾 Updating people records...');
      
      for (const update of updates) {
        await conn.execute(
          `UPDATE familytree_people 
           SET Gender = ?, Age = ?, Life_Status = ?, Marital_Status = ? 
           WHERE \`Personal _ID\` = ?`,
          [update.gender, update.age, update.lifeStatus, update.maritalStatus, update.personId]
        );
      }
      
      console.log(`✅ Updated ${updates.length} people records`);
    }
    
    // Process families for Father/Mother names and Marriage Year
    console.log('🔄 Processing families data...');
    
    const familyUpdates = [];
    let familyUpdatedCount = 0;
    
    for (const family of families) {
      const familyId = family.Family_ID;
      const fatherId = family.Father_ID;
      const motherId = family.Mother_ID;
      const marriageYear = family.Marriage_Year;
      
      // Get father and mother names
      const father = fatherId ? peopleMap.get(fatherId) : null;
      const mother = motherId ? peopleMap.get(motherId) : null;
      
      const fatherName = father ? `${father.Forenames} ${father.Surname}`.trim() : 'Unknown';
      const motherName = mother ? `${mother.Forenames} ${mother.Surname}`.trim() : 'Unknown';
      const marriageYearDisplay = marriageYear || 'Unknown';
      
      // Check if we need to add these fields to the families table
      // (assuming they don't exist yet, we'll add them)
      familyUpdates.push({
        familyId,
        fatherName,
        motherName,
        marriageYearDisplay
      });
    }
    
    console.log(`📝 Found ${familyUpdates.length} families to process`);
    
    // Add derived fields to families table if they don't exist
    try {
      await conn.execute('ALTER TABLE familytree_families ADD COLUMN IF NOT EXISTS Father_Name VARCHAR(255) DEFAULT "Unknown"');
      await conn.execute('ALTER TABLE familytree_families ADD COLUMN IF NOT EXISTS Mother_Name VARCHAR(255) DEFAULT "Unknown"');
      await conn.execute('ALTER TABLE familytree_families ADD COLUMN IF NOT EXISTS Marriage_Year_Display VARCHAR(50) DEFAULT "Unknown"');
      console.log('✅ Added derived fields to families table');
    } catch (error) {
      console.log('ℹ️  Derived fields may already exist in families table');
    }
    
    // Update families with derived values
    if (familyUpdates.length > 0) {
      console.log('💾 Updating families records...');
      
      for (const update of familyUpdates) {
        await conn.execute(
          `UPDATE familytree_families 
           SET Father_Name = ?, Mother_Name = ?, Marriage_Year_Display = ? 
           WHERE Family_ID = ?`,
          [update.fatherName, update.motherName, update.marriageYearDisplay, update.familyId]
        );
      }
      
      console.log(`✅ Updated ${familyUpdates.length} families records`);
    }
    
    // Generate summary statistics
    console.log('\n📊 Processing Summary:');
    console.log(`👥 People processed: ${people.length}`);
    console.log(`👥 People updated: ${updatedCount}`);
    console.log(`🏠 Families processed: ${families.length}`);
    console.log(`🏠 Families updated: ${familyUpdates.length}`);
    
    // Show gender distribution
    const genderStats = updates.reduce((acc, u) => {
      acc[u.gender] = (acc[u.gender] || 0) + 1;
      return acc;
    }, {});
    console.log('\n📈 Gender Distribution:');
    Object.entries(genderStats).forEach(([gender, count]) => {
      console.log(`   ${gender}: ${count}`);
    });
    
    // Show marital status distribution
    const maritalStats = updates.reduce((acc, u) => {
      acc[u.maritalStatus] = (acc[u.maritalStatus] || 0) + 1;
      return acc;
    }, {});
    console.log('\n💍 Marital Status Distribution:');
    Object.entries(maritalStats).forEach(([status, count]) => {
      console.log(`   ${status}: ${count}`);
    });
    
    // Show life status distribution
    const lifeStats = updates.reduce((acc, u) => {
      acc[u.lifeStatus] = (acc[u.lifeStatus] || 0) + 1;
      return acc;
    }, {});
    console.log('\n❤️ Life Status Distribution:');
    Object.entries(lifeStats).forEach(([status, count]) => {
      console.log(`   ${status}: ${count}`);
    });
    
    console.log('\n🎉 Database update completed successfully!');
    
  } catch (error) {
    console.error('❌ Error updating database:', error);
    throw error;
  } finally {
    if (conn) await conn.end();
  }
}

// Run the update
updateDerivedValues().catch(console.error);
