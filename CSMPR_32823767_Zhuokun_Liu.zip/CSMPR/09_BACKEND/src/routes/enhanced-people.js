const express = require('express');
const router = express.Router();
const { pool } = require('../db');

// Enhanced People endpoint with derived values from database
router.get('/', async (req, res) => {
  try {
    // Get all people data with proper NULL handling
    const [peopleRows] = await pool.query(`
      SELECT 
        \`Personal _ID\`,
        COALESCE(Forenames, 'Unknown') as Forenames,
        COALESCE(Surname, 'Unknown') as Surname,
        COALESCE(\`Birth_Year\`, 'Unknown') as \`Birth_Year\`,
        COALESCE(\`Death_Year\`, 'Unknown') as \`Death_Year\`,
        COALESCE(\`Spouse_ID\`, 'Unknown') as \`Spouse_ID\`,
        COALESCE(\`Parents_ID\`, 'Unknown') as \`Parents_ID\`,
        COALESCE(\`Marriage_Year\`, 'Unknown') as \`Marriage_Year\`
      FROM \`familytree_people\`
      ORDER BY \`Personal _ID\`
    `);
    
    // Get all families data to determine gender relationships
    const [familiesRows] = await pool.query(`
      SELECT 
        \`Father ID\`,
        \`Mother_ID\`
      FROM \`familytree_families\`
      WHERE \`Father ID\` IS NOT NULL AND \`Father ID\` != '' 
         OR \`Mother_ID\` IS NOT NULL AND \`Mother_ID\` != ''
    `);
    
    // Create sets for quick lookup
    const fatherIds = new Set();
    const motherIds = new Set();
    
    familiesRows.forEach(family => {
      if (family['Father ID'] && family['Father ID'].trim() && family['Father ID'] !== 'Unknown') {
        fatherIds.add(family['Father ID'].trim());
      }
      if (family['Mother_ID'] && family['Mother_ID'].trim() && family['Mother_ID'] !== 'Unknown') {
        motherIds.add(family['Mother_ID'].trim());
      }
    });
    
    // Process each person with derived values
    const enhancedPeople = peopleRows.map(person => {
      const personalId = person['Personal _ID'];
      
      // Derive Gender based on family relationships
      let gender = 'Unknown';
      if (fatherIds.has(personalId)) {
        gender = 'Male';
      } else if (motherIds.has(personalId)) {
        gender = 'Female';
      }
      
      // Derive Age and Life_Status
      let age = 'Unknown';
      let lifeStatus = 'Unknown';
      
      const birthYear = person['Birth_Year'];
      const deathYear = person['Death_Year'];
      
      // Handle birth year validation
      const isValidBirthYear = birthYear && birthYear !== 'Unknown' && !isNaN(birthYear) && parseInt(birthYear) > 0;
      const isValidDeathYear = deathYear && deathYear !== 'Unknown' && !isNaN(deathYear) && parseInt(deathYear) > 0;
      
      if (isValidDeathYear) {
        // Has death year - mark as Deceased
        lifeStatus = 'Deceased';
        if (isValidBirthYear) {
          const birthYearNum = parseInt(birthYear);
          const deathYearNum = parseInt(deathYear);
          const calculatedAge = deathYearNum - birthYearNum;
          if (calculatedAge > 0 && calculatedAge < 150) { // Reasonable age range
            age = calculatedAge;
          }
        }
      } else if (isValidBirthYear) {
        // No death year, check birth year
        const birthYearNum = parseInt(birthYear);
        const currentYear = new Date().getFullYear();
        const calculatedAge = currentYear - birthYearNum;
        
        if (birthYearNum >= 1900) {
          // Birth_Year >= 1900 and no Death_Year - mark as Living person
          lifeStatus = 'Living person';
          if (calculatedAge > 0 && calculatedAge < 150) {
            age = calculatedAge;
          }
        } else {
          // Birth_Year < 1900 and no Death_Year - check if age > 130
          if (calculatedAge > 130) {
            lifeStatus = 'Deceased';
          } else if (calculatedAge > 0) {
            lifeStatus = 'Living person';
            age = calculatedAge;
          }
        }
      }
      
      // Derive Marital_Status
      let maritalStatus = 'Single';
      if (person['Spouse_ID'] && person['Spouse_ID'] !== 'Unknown' && person['Spouse_ID'].trim()) {
        maritalStatus = 'Married';
      }
      
      return {
        'Personal _ID': personalId,
        'Forenames': person.Forenames,
        'Surname': person.Surname,
        'Birth_Year': person['Birth_Year'],
        'Death_Year': person['Death_Year'],
        'Spouse_ID': person['Spouse_ID'],
        'Parents_ID': person['Parents_ID'],
        'Marriage_Year': person['Marriage_Year'],
        'Gender': gender,
        'Age': age,
        'Life_Status': lifeStatus,
        'Marital_Status': maritalStatus
      };
    });
    
    res.json(enhancedPeople);
  } catch (err) {
    console.error('Enhanced people endpoint error:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

module.exports = router;
