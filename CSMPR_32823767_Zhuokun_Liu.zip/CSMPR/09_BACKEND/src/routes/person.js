const express = require('express');
const router = express.Router();
const { pool } = require('../db');

async function fetchPeopleByIds(ids) {
  if (!ids || ids.length === 0) return [];
  const placeholders = ids.map(() => '?').join(',');
  const [rows] = await pool.query(
    `SELECT * FROM familytree_people WHERE \`Personal _ID\` IN (${placeholders})`,
    ids
  );
  return rows;
}

function extractChildrenIds(familyRow) {
  const keys = [
    'Child_ID_1','Child_ID_2','Child_ID_3','Child_ID_4','Child_ID_5',
    'Child_ID_6','Child_ID_7','Child_ID_8','Child_ID_9','Child_ID_10'
  ];
  const ids = [];
  for (const k of keys) {
    const v = familyRow[k];
    if (v && String(v).trim()) ids.push(String(v).trim());
  }
  return ids;
}

router.get('/:id', async (req, res) => {
  const id = String(req.params.id);
  try {
    const [peopleRows] = await pool.query(
      'SELECT * FROM familytree_people WHERE `Personal _ID` = ?',
      [id]
    );
    if (peopleRows.length === 0) return res.status(404).json({ error: 'Not found' });
    const person = peopleRows[0];

    // Parents via the family in `Parents_ID`
    const parents = [];
    const parentsFamilyId = person['Parents_ID'] && String(person['Parents_ID']).trim();
    if (parentsFamilyId) {
      const [famRows] = await pool.query(
        'SELECT * FROM familytree_families WHERE `Family_ID` = ?',
        [parentsFamilyId]
      );
      if (famRows.length > 0) {
        const fam = famRows[0];
        const fatherId = fam['Father ID'] && String(fam['Father ID']).trim();
        const motherId = fam['Mother_ID'] && String(fam['Mother_ID']).trim();
        const ids = [fatherId, motherId].filter(Boolean);
        if (ids.length) {
          const fetched = await fetchPeopleByIds(ids);
          parents.push(...fetched);
        }
      }
    }

    // Families where this person is a spouse
    const [marriageFamilies] = await pool.query(
      'SELECT * FROM familytree_families WHERE `Father ID` = ? OR `Mother_ID` = ?',
      [id, id]
    );

    // Spouses: the other person in those families
    const spouseIdsSet = new Set();
    for (const fam of marriageFamilies) {
      const father = fam['Father ID'] && String(fam['Father ID']).trim();
      const mother = fam['Mother_ID'] && String(fam['Mother_ID']).trim();
      const other = father === id ? mother : father;
      if (other) spouseIdsSet.add(other);
    }
    const spouses = await fetchPeopleByIds(Array.from(spouseIdsSet));

    // Children: union of all children across those families
    const childIds = Array.from(
      new Set(marriageFamilies.flatMap(extractChildrenIds))
    );
    const children = await fetchPeopleByIds(childIds);

    res.json({ person, parents, spouses, children });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database error' });
  }
});

module.exports = router;


