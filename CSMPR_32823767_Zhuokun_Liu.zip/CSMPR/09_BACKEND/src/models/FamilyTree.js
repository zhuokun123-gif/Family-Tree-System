const Member = require('./Member');

class FamilyTree {
    constructor() {
        this.members = new Map(); // personalId -> Member
        this.families = new Map(); // familyId -> Family
        this.generations = new Map(); // generation -> [Member]
        this.birthdaySortedList = [];
        this.rootMember = null;
    }

    // Add a member to the tree
    addMember(memberData, parentId = null) {
        const member = new Member(memberData);
        
        // Check for duplicate names (optional)
        if (this.hasDuplicateName(member)) {
            throw new Error(`Duplicate name found: ${member.fullName}`);
        }

        this.members.set(member.personalId, member);

        // Set parent relationship
        if (parentId && this.members.has(parentId)) {
            const parent = this.members.get(parentId);
            member.parentsFamilyId = parent.parentsFamilyId;
            parent.addChild(member.personalId);
        }

        // Recalculate generations
        this.recalculateGenerations();
        
        // Update birthday sorting
        this.updateBirthdaySorting();

        return member;
    }

    // Delete a member and all descendants
    deleteMember(memberId) {
        if (!this.members.has(memberId)) {
            throw new Error(`Member not found: ${memberId}`);
        }

        const member = this.members.get(memberId);
        
        // Remove from parent's children
        if (member.parentsFamilyId) {
            const parentFamily = this.families.get(member.parentsFamilyId);
            if (parentFamily) {
                if (parentFamily.fatherId === memberId) {
                    parentFamily.fatherId = null;
                } else if (parentFamily.motherId === memberId) {
                    parentFamily.motherId = null;
                }
            }
        }

        // Remove from spouse relationships
        member.spouseIds.forEach(spouseId => {
            const spouse = this.members.get(spouseId);
            if (spouse) {
                spouse.removeSpouse(memberId);
            }
        });

        // Recursively delete all descendants
        this.deleteDescendants(memberId);

        // Remove the member
        this.members.delete(memberId);

        // Recalculate generations and sorting
        this.recalculateGenerations();
        this.updateBirthdaySorting();
    }

    // Recursively delete all descendants
    deleteDescendants(memberId) {
        const member = this.members.get(memberId);
        if (!member) return;

        // Delete all children first
        member.childrenIds.forEach(childId => {
            this.deleteDescendants(childId);
            this.members.delete(childId);
        });

        // Clear children array
        member.childrenIds = [];
    }

    // Move a member to a new parent
    moveMember(memberId, newParentId) {
        if (!this.members.has(memberId)) {
            throw new Error(`Member not found: ${memberId}`);
        }

        if (newParentId && !this.members.has(newParentId)) {
            throw new Error(`New parent not found: ${newParentId}`);
        }

        const member = this.members.get(memberId);
        const oldParentId = member.parentsFamilyId;

        // Remove from old parent
        if (oldParentId) {
            const oldParent = this.members.get(oldParentId);
            if (oldParent) {
                oldParent.removeChild(memberId);
            }
        }

        // Add to new parent
        if (newParentId) {
            const newParent = this.members.get(newParentId);
            newParent.addChild(memberId);
            member.parentsFamilyId = newParent.parentsFamilyId;
        } else {
            member.parentsFamilyId = null;
        }

        // Recalculate generations for the moved member and descendants
        this.recalculateGenerationsForMember(memberId);
    }

    // Search for members by name
    searchByName(name) {
        const results = [];
        const searchName = name.toLowerCase();

        for (const member of this.members.values()) {
            if (member.fullName.toLowerCase().includes(searchName)) {
                results.push(member);
            }
        }

        return results;
    }

    // Get direct relatives (parents, children, spouses)
    getDirectRelatives(memberId) {
        if (!this.members.has(memberId)) return [];

        const member = this.members.get(memberId);
        const relatives = [];

        // Get parents
        if (member.parentsFamilyId) {
            const family = this.families.get(member.parentsFamilyId);
            if (family) {
                if (family.fatherId && this.members.has(family.fatherId)) {
                    const father = this.members.get(family.fatherId);
                    relatives.push({
                        member: father,
                        relationship: 'Father',
                        degree: 1
                    });
                }
                if (family.motherId && this.members.has(family.motherId)) {
                    const mother = this.members.get(family.motherId);
                    relatives.push({
                        member: mother,
                        relationship: 'Mother',
                        degree: 1
                    });
                }
            }
        }

        // Get children
        member.childrenIds.forEach(childId => {
            if (this.members.has(childId)) {
                const child = this.members.get(childId);
                relatives.push({
                    member: child,
                    relationship: 'Child',
                    degree: 1
                });
            }
        });

        // Get spouses
        member.spouseIds.forEach(spouseId => {
            if (this.members.has(spouseId)) {
                const spouse = this.members.get(spouseId);
                relatives.push({
                    member: spouse,
                    relationship: 'Spouse',
                    degree: 0
                });
            }
        });

        return relatives;
    }

    // Get collateral relatives (siblings, cousins, uncles, aunts, etc.)
    getCollateralRelatives(memberId) {
        if (!this.members.has(memberId)) return [];

        const member = this.members.get(memberId);
        const relatives = [];

        // Get siblings
        if (member.parentsFamilyId) {
            const family = this.families.get(member.parentsFamilyId);
            if (family) {
                // Get all children of the same parents
                const allChildren = [];
                if (family.fatherId && this.members.has(family.fatherId)) {
                    const father = this.members.get(family.fatherId);
                    allChildren.push(...father.childrenIds);
                }
                if (family.motherId && this.members.has(family.motherId)) {
                    const mother = this.members.get(family.motherId);
                    allChildren.push(...mother.childrenIds);
                }

                // Remove duplicates and the current member
                const uniqueChildren = [...new Set(allChildren)].filter(id => id !== memberId);
                
                uniqueChildren.forEach(childId => {
                    if (this.members.has(childId)) {
                        const sibling = this.members.get(childId);
                        relatives.push({
                            member: sibling,
                            relationship: 'Sibling',
                            degree: 1
                        });
                    }
                });
            }
        }

        // Get cousins (children of siblings)
        const siblings = relatives.filter(r => r.relationship === 'Sibling');
        siblings.forEach(sibling => {
            sibling.member.childrenIds.forEach(cousinId => {
                if (this.members.has(cousinId)) {
                    const cousin = this.members.get(cousinId);
                    relatives.push({
                        member: cousin,
                        relationship: 'Cousin',
                        degree: 2
                    });
                }
            });
        });

        // Get uncles and aunts (siblings of parents)
        if (member.parentsFamilyId) {
            const family = this.families.get(member.parentsFamilyId);
            if (family) {
                // Get father's siblings
                if (family.fatherId && this.members.has(family.fatherId)) {
                    const father = this.members.get(family.fatherId);
                    if (father.parentsFamilyId) {
                        const fatherFamily = this.families.get(father.parentsFamilyId);
                        if (fatherFamily) {
                            const fatherSiblings = [];
                            if (fatherFamily.fatherId && this.members.has(fatherFamily.fatherId)) {
                                const grandfather = this.members.get(fatherFamily.fatherId);
                                fatherSiblings.push(...grandfather.childrenIds);
                            }
                            if (fatherFamily.motherId && this.members.has(fatherFamily.motherId)) {
                                const grandmother = this.members.get(fatherFamily.motherId);
                                fatherSiblings.push(...grandmother.childrenIds);
                            }
                            
                            const uniqueFatherSiblings = [...new Set(fatherSiblings)].filter(id => id !== family.fatherId);
                            uniqueFatherSiblings.forEach(siblingId => {
                                if (this.members.has(siblingId)) {
                                    const uncleAunt = this.members.get(siblingId);
                                    relatives.push({
                                        member: uncleAunt,
                                        relationship: 'Uncle/Aunt',
                                        degree: 2
                                    });
                                }
                            });
                        }
                    }
                }

                // Get mother's siblings
                if (family.motherId && this.members.has(family.motherId)) {
                    const mother = this.members.get(family.motherId);
                    if (mother.parentsFamilyId) {
                        const motherFamily = this.families.get(mother.parentsFamilyId);
                        if (motherFamily) {
                            const motherSiblings = [];
                            if (motherFamily.fatherId && this.members.has(motherFamily.fatherId)) {
                                const grandfather = this.members.get(motherFamily.fatherId);
                                motherSiblings.push(...grandfather.childrenIds);
                            }
                            if (motherFamily.motherId && this.members.has(motherFamily.motherId)) {
                                const grandmother = this.members.get(motherFamily.motherId);
                                motherSiblings.push(...grandmother.childrenIds);
                            }
                            
                            const uniqueMotherSiblings = [...new Set(motherSiblings)].filter(id => id !== family.motherId);
                            uniqueMotherSiblings.forEach(siblingId => {
                                if (this.members.has(siblingId)) {
                                    const uncleAunt = this.members.get(siblingId);
                                    relatives.push({
                                        member: uncleAunt,
                                        relationship: 'Uncle/Aunt',
                                        degree: 2
                                    });
                                }
                            });
                        }
                    }
                }
            }
        }

        // Get nephews and nieces (children of siblings)
        siblings.forEach(sibling => {
            sibling.member.childrenIds.forEach(nephewId => {
                if (this.members.has(nephewId)) {
                    const nephew = this.members.get(nephewId);
                    relatives.push({
                        member: nephew,
                        relationship: 'Nephew/Niece',
                        degree: 2
                    });
                }
            });
        });

        // Get grandparents
        if (member.parentsFamilyId) {
            const family = this.families.get(member.parentsFamilyId);
            if (family) {
                // Paternal grandfather
                if (family.fatherId && this.members.has(family.fatherId)) {
                    const father = this.members.get(family.fatherId);
                    if (father.parentsFamilyId) {
                        const fatherFamily = this.families.get(father.parentsFamilyId);
                        if (fatherFamily && fatherFamily.fatherId && this.members.has(fatherFamily.fatherId)) {
                            const grandfather = this.members.get(fatherFamily.fatherId);
                            relatives.push({
                                member: grandfather,
                                relationship: 'Paternal Grandfather',
                                degree: 2
                            });
                        }
                        if (fatherFamily && fatherFamily.motherId && this.members.has(fatherFamily.motherId)) {
                            const grandmother = this.members.get(fatherFamily.motherId);
                            relatives.push({
                                member: grandmother,
                                relationship: 'Paternal Grandmother',
                                degree: 2
                            });
                        }
                    }
                }

                // Maternal grandfather
                if (family.motherId && this.members.has(family.motherId)) {
                    const mother = this.members.get(family.motherId);
                    if (mother.parentsFamilyId) {
                        const motherFamily = this.families.get(mother.parentsFamilyId);
                        if (motherFamily && motherFamily.fatherId && this.members.has(motherFamily.fatherId)) {
                            const grandfather = this.members.get(motherFamily.fatherId);
                            relatives.push({
                                member: grandfather,
                                relationship: 'Maternal Grandfather',
                                degree: 2
                            });
                        }
                        if (motherFamily && motherFamily.motherId && this.members.has(motherFamily.motherId)) {
                            const grandmother = this.members.get(motherFamily.motherId);
                            relatives.push({
                                member: grandmother,
                                relationship: 'Maternal Grandmother',
                                degree: 2
                            });
                        }
                    }
                }
            }
        }

        return relatives;
    }

    // Check if two members are direct relatives
    areDirectRelatives(id1, id2) {
        if (!this.members.has(id1) || !this.members.has(id2)) return false;
        
        const member1 = this.members.get(id1);
        const member2 = this.members.get(id2);
        
        // Check parent-child relationship
        if (member1.parentsFamilyId) {
            const family = this.families.get(member1.parentsFamilyId);
            if (family && (family.fatherId === id2 || family.motherId === id2)) {
                return true;
            }
        }
        
        if (member2.parentsFamilyId) {
            const family = this.families.get(member2.parentsFamilyId);
            if (family && (family.fatherId === id1 || family.motherId === id1)) {
                return true;
            }
        }
        
        // Check spouse relationship
        return member1.spouseIds.includes(id2) || member2.spouseIds.includes(id1);
    }

    // Check if two members are collateral relatives
    areCollateralRelatives(id1, id2) {
        if (!this.members.has(id1) || !this.members.has(id2)) return false;
        
        const member1 = this.members.get(id1);
        const member2 = this.members.get(id2);
        
        // Check if they share a common ancestor (siblings, cousins, etc.)
        return this.findCommonAncestor(member1, member2) !== null;
    }

    // Find common ancestor between two members
    findCommonAncestor(member1, member2) {
        const ancestors1 = this.getAncestors(member1.personalId);
        const ancestors2 = this.getAncestors(member2.personalId);
        
        for (const ancestor1 of ancestors1) {
            for (const ancestor2 of ancestors2) {
                if (ancestor1.member.personalId === ancestor2.member.personalId) {
                    return ancestor1.member;
                }
            }
        }
        
        return null;
    }

    // Get ancestors of a member
    getAncestors(memberId, maxDepth = 5) {
        const ancestors = [];
        const visited = new Set();
        
        const traverse = (id, depth) => {
            if (depth >= maxDepth || visited.has(id)) return;
            visited.add(id);
            
            const member = this.members.get(id);
            if (!member || !member.parentsFamilyId) return;
            
            const family = this.families.get(member.parentsFamilyId);
            if (!family) return;
            
            if (family.fatherId && this.members.has(family.fatherId)) {
                const father = this.members.get(family.fatherId);
                ancestors.push({ member: father, generation: depth + 1 });
                traverse(family.fatherId, depth + 1);
            }
            
            if (family.motherId && this.members.has(family.motherId)) {
                const mother = this.members.get(family.motherId);
                ancestors.push({ member: mother, generation: depth + 1 });
                traverse(family.motherId, depth + 1);
            }
        };
        
        traverse(memberId, 0);
        return ancestors;
    }

    // Recalculate generations for all members
    recalculateGenerations() {
        this.generations.clear();
        
        // Find root members (those without parents)
        const rootMembers = [];
        for (const member of this.members.values()) {
            if (!member.parentsFamilyId) {
                rootMembers.push(member);
            }
        }
        
        // If no root members found, use the first member as root
        if (rootMembers.length === 0 && this.members.size > 0) {
            rootMembers.push(this.members.values().next().value);
        }
        
        // Calculate generations starting from roots
        rootMembers.forEach(root => {
            this.calculateGenerationForMember(root, 0);
        });
    }

    // Calculate generation for a specific member and descendants
    recalculateGenerationsForMember(memberId) {
        const member = this.members.get(memberId);
        if (!member) return;
        
        // Find the generation of this member's parents
        let parentGeneration = -1;
        if (member.parentsFamilyId) {
            const family = this.families.get(member.parentsFamilyId);
            if (family) {
                if (family.fatherId && this.members.has(family.fatherId)) {
                    const father = this.members.get(family.fatherId);
                    parentGeneration = father.generation;
                }
                if (family.motherId && this.members.has(family.motherId)) {
                    const mother = this.members.get(family.motherId);
                    parentGeneration = Math.max(parentGeneration, mother.generation);
                }
            }
        }
        
        // Set this member's generation
        member.generation = parentGeneration + 1;
        
        // Update generations map
        if (!this.generations.has(member.generation)) {
            this.generations.set(member.generation, []);
        }
        this.generations.get(member.generation).push(member);
        
        // Recursively update descendants
        member.childrenIds.forEach(childId => {
            this.recalculateGenerationsForMember(childId);
        });
    }

    // Calculate generation for a member and all descendants
    calculateGenerationForMember(member, generation) {
        member.generation = generation;
        
        if (!this.generations.has(generation)) {
            this.generations.set(generation, []);
        }
        this.generations.get(generation).push(member);
        
        // Recursively calculate for children
        member.childrenIds.forEach(childId => {
            if (this.members.has(childId)) {
                const child = this.members.get(childId);
                this.calculateGenerationForMember(child, generation + 1);
            }
        });
    }

    // Update birthday sorting list
    updateBirthdaySorting() {
        this.birthdaySortedList = Array.from(this.members.values())
            .filter(member => member.birthYear)
            .sort((a, b) => {
                if (a.birthYear !== b.birthYear) {
                    return a.birthYear - b.birthYear;
                }
                return a.fullName.localeCompare(b.fullName);
            });
    }

    // Check for duplicate names
    hasDuplicateName(member) {
        for (const existingMember of this.members.values()) {
            if (existingMember.personalId !== member.personalId && 
                existingMember.fullName === member.fullName) {
                return true;
            }
        }
        return false;
    }

    // Get tree statistics
    getTreeStats() {
        const totalMembers = this.members.size;
        const aliveMembers = Array.from(this.members.values()).filter(m => m.isAlive).length;
        const deadMembers = totalMembers - aliveMembers;
        const generations = this.generations.size;
        
        return {
            totalMembers,
            aliveMembers,
            deadMembers,
            generations,
            birthdayMembers: this.birthdaySortedList.length
        };
    }

    // Get members by generation
    getMembersByGeneration(generation) {
        return this.generations.get(generation) || [];
    }

    // Get birthday members (those with birthdays today)
    getBirthdayMembers() {
        const today = new Date();
        const currentMonth = today.getMonth() + 1;
        const currentDay = today.getDate();
        
        return Array.from(this.members.values()).filter(member => {
            if (!member.birthYear) return false;
            
            // Simple check - could be enhanced with actual birth month/day
            return member.isAlive;
        });
    }

    // Export tree data
    exportTree() {
        const exportData = {
            members: Array.from(this.members.values()).map(member => member.toJSON()),
            families: Array.from(this.families.values()),
            stats: this.getTreeStats(),
            generations: Object.fromEntries(this.generations)
        };
        
        return exportData;
    }
}

module.exports = FamilyTree;