const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');

dotenv.config();

const peopleRouter = require('./routes/people');
const familiesRouter = require('./routes/families');
const personRouter = require('./routes/person');
const adminRouter = require('./routes/admin');
const enhancedTreeRouter = require('./routes/enhanced-tree');
const enhancedPeopleRouter = require('./routes/enhanced-people');
const enhancedFamiliesRouter = require('./routes/enhanced-families');

const app = express();

app.use(cors({ origin: process.env.CORS_ORIGIN || '*', credentials: true }));
app.use(express.json());

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok' });
});

app.use('/api/people', peopleRouter);
app.use('/api/families', familiesRouter);
app.use('/api/person', personRouter);
app.use('/api/admin', adminRouter);
app.use('/api/enhanced-tree', enhancedTreeRouter);
app.use('/api/enhanced-people', enhancedPeopleRouter);
app.use('/api/enhanced-families', enhancedFamiliesRouter);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server listening on http://localhost:${PORT}`);
});


