const express = require('express');
const router = express.Router();
const { pool } = require('../db');
const FamilyTree = require('../models/FamilyTree');
const Member = require('../models/Member');

// Initialize family tree from database
async function initializeFamilyTree() {
    const familyTree = new FamilyTree();
    
    try {
        // Load all people
        const [peopleRows] = await pool.query('SELECT * FROM familytree_people');
        const [familyRows] = await pool.query('SELECT * FROM familytree_families');
        
        // Create members
        peopleRows.forEach(personData => {
            const member = new Member(personData);
            familyTree.members.set(member.personalId, member);
        });
        
        // Process families to establish relationships
        familyRows.forEach(familyData => {
            const familyId = familyData['Family_ID'];
            const fatherId = familyData['Father ID'];
            const motherId = familyData['Mother_ID'];
            
            // Get child IDs from the family
            const childIds = [];
            for (let i = 1; i <= 10; i++) {
                const childId = familyData[`Child_ID_${i}`];
                if (childId && childId.trim()) {
                    childIds.push(childId.trim());
                }
            }
            
            // Establish parent-child relationships
            childIds.forEach(childId => {
                const child = familyTree.members.get(childId);
                if (child) {
                    child.parentsFamilyId = familyId;
                    
                    // Add to father's children
                    if (fatherId && familyTree.members.has(fatherId)) {
                        const father = familyTree.members.get(fatherId);
                        father.addChild(childId);
                    }
                    
                    // Add to mother's children
                    if (motherId && familyTree.members.has(motherId)) {
                        const mother = familyTree.members.get(motherId);
                        mother.addChild(childId);
                    }
                }
            });
            
            // Store family data
            familyTree.families.set(familyId, {
                familyId,
                fatherId,
                motherId,
                childIds
            });
        });
        
        // Recalculate generations and relationships
        familyTree.recalculateGenerations();
        familyTree.updateBirthdaySorting();
        
        return familyTree;
    } catch (error) {
        console.error('Error initializing family tree:', error);
        throw error;
    }
}

// Get enhanced tree data for a person
router.get('/person/:id', async (req, res) => {
    try {
        const personId = req.params.id;
        const familyTree = await initializeFamilyTree();
        
        if (!familyTree.members.has(personId)) {
            return res.status(404).json({ error: 'Person not found' });
        }
        
        const person = familyTree.members.get(personId);
        const directRelatives = familyTree.getDirectRelatives(personId);
        const collateralRelatives = familyTree.getCollateralRelatives(personId);
        
        // Get all relatives with relationship information
        const allRelatives = [
            ...directRelatives.map(rel => ({
                ...rel,
                type: 'direct'
            })),
            ...collateralRelatives.map(rel => ({
                ...rel,
                type: 'collateral'
            }))
        ];
        
        // Group relatives by relationship type
        const relativesByType = {
            parents: directRelatives.filter(rel => ['Father', 'Mother'].includes(rel.relationship)),
            children: directRelatives.filter(rel => rel.relationship === 'Child'),
            spouses: directRelatives.filter(rel => rel.relationship === 'Spouse'),
            siblings: collateralRelatives.filter(rel => rel.relationship === 'Sibling'),
            grandparents: collateralRelatives.filter(rel => rel.relationship.includes('Grandfather') || rel.relationship.includes('Grandmother')),
            uncles: collateralRelatives.filter(rel => rel.relationship === 'Uncle/Aunt'),
            cousins: collateralRelatives.filter(rel => rel.relationship === 'Cousin'),
            nephews: collateralRelatives.filter(rel => rel.relationship === 'Nephew/Niece')
        };
        
        // Enhance spouse data with their parents information
        if (relativesByType.spouses && relativesByType.spouses.length > 0) {
            relativesByType.spouses.forEach(spouse => {
                if (spouse.member && spouse.member.personalId) {
                    // Get spouse's parents
                    const spouseParents = familyTree.getDirectRelatives(spouse.member.personalId)
                        .filter(rel => ['Father', 'Mother'].includes(rel.relationship));
                    
                    // Add parents to spouse member object
                    spouse.member.parents = spouseParents.map(rel => rel.member.toJSON());
                }
            });
        }
        
        res.json({
            person: person.toJSON(),
            relatives: allRelatives,
            relativesByType,
            treeStats: familyTree.getTreeStats(),
            generations: Object.fromEntries(familyTree.generations)
        });
        
    } catch (error) {
        console.error('Error getting enhanced person data:', error);
        res.status(500).json({ error: 'Database error' });
    }
});

// Search members by name
router.get('/search/:name', async (req, res) => {
    try {
        const searchName = req.params.name;
        const familyTree = await initializeFamilyTree();
        
        const results = familyTree.searchByName(searchName);
        
        res.json({
            searchTerm: searchName,
            results: results.map(member => member.toJSON()),
            count: results.length
        });
        
    } catch (error) {
        console.error('Error searching members:', error);
        res.status(500).json({ error: 'Database error' });
    }
});

// Get tree statistics
router.get('/stats', async (req, res) => {
    try {
        const familyTree = await initializeFamilyTree();
        
        res.json({
            stats: familyTree.getTreeStats(),
            generations: Object.fromEntries(
                Array.from(familyTree.generations.entries()).map(([gen, members]) => [
                    gen,
                    {
                        count: members.length,
                        members: members.map(m => ({
                            id: m.personalId,
                            name: m.fullName,
                            birthYear: m.birthYear,
                            isAlive: m.isAlive
                        }))
                    }
                ])
            )
        });
        
    } catch (error) {
        console.error('Error getting tree stats:', error);
        res.status(500).json({ error: 'Database error' });
    }
});

// Get birthday members
router.get('/birthdays', async (req, res) => {
    try {
        const familyTree = await initializeFamilyTree();
        
        const birthdayMembers = familyTree.getBirthdayMembers();
        
        res.json({
            today: new Date().toISOString().split('T')[0],
            birthdayMembers: birthdayMembers.map(member => member.toJSON()),
            count: birthdayMembers.length
        });
        
    } catch (error) {
        console.error('Error getting birthday members:', error);
        res.status(500).json({ error: 'Database error' });
    }
});

// Get members by generation
router.get('/generation/:gen', async (req, res) => {
    try {
        const generation = parseInt(req.params.gen);
        const familyTree = await initializeFamilyTree();
        
        const members = familyTree.getMembersByGeneration(generation);
        
        res.json({
            generation,
            members: members.map(member => member.toJSON()),
            count: members.length
        });
        
    } catch (error) {
        console.error('Error getting generation members:', error);
        res.status(500).json({ error: 'Database error' });
    }
});

// Check relationship between two members
router.get('/relationship/:id1/:id2', async (req, res) => {
    try {
        const { id1, id2 } = req.params;
        const familyTree = await initializeFamilyTree();
        
        if (!familyTree.members.has(id1) || !familyTree.members.has(id2)) {
            return res.status(404).json({ error: 'One or both members not found' });
        }
        
        const member1 = familyTree.members.get(id1);
        const member2 = familyTree.members.get(id2);
        
        const isDirect = familyTree.areDirectRelatives(id1, id2);
        const isCollateral = familyTree.areCollateralRelatives(id1, id2);
        
        let relationshipType = 'No Relation';
        let degree = -1;
        
        if (id1 === id2) {
            relationshipType = 'Same Person';
            degree = 0;
        } else if (isDirect) {
            const directRelatives = familyTree.getDirectRelatives(id1);
            const rel = directRelatives.find(r => r.member.personalId === id2);
            if (rel) {
                relationshipType = rel.relationship;
                degree = rel.degree;
            }
        } else if (isCollateral) {
            const collateralRelatives = familyTree.getCollateralRelatives(id1);
            const rel = collateralRelatives.find(r => r.member.personalId === id2);
            if (rel) {
                relationshipType = rel.relationship;
                degree = rel.degree;
            }
        }
        
        res.json({
            member1: member1.toJSON(),
            member2: member2.toJSON(),
            relationship: {
                type: relationshipType,
                degree,
                isDirect,
                isCollateral
            }
        });
        
    } catch (error) {
        console.error('Error checking relationship:', error);
        res.status(500).json({ error: 'Database error' });
    }
});

module.exports = router;
