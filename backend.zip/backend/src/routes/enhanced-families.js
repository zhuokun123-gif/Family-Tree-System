const express = require('express');
const router = express.Router();
const { pool } = require('../db');

// Enhanced Families endpoint with derived values from database
router.get('/', async (req, res) => {
  try {
    // Get all families data with proper JOIN queries and NULL handling
    const [familiesRows] = await pool.query(`
      SELECT 
        f.Family_ID,
        COALESCE(f.\`Father ID\`, 'Unknown') as \`Father ID\`,
        COALESCE(f.\`Mother_ID\`, 'Unknown') as \`Mother_ID\`,
        COALESCE(f.Father_Name, 'Unknown') as Father_Name,
        COALESCE(f.Mother_Name, 'Unknown') as Mother_Name,
        COALESCE(f.Marriage_Year_Display, 'Unknown') as Marriage_Year_Display,
        f.Child_ID_1,
        f.Child_ID_2,
        f.Child_ID_3,
        f.Child_ID_4,
        f.Child_ID_5,
        f.Child_ID_6,
        f.Child_ID_7,
        f.Child_ID_8,
        f.Child_ID_9,
        f.Child_ID_10
      FROM \`familytree_families\` f
      ORDER BY f.Family_ID
    `);
    
    // Get all people data to get names for children
    const [peopleRows] = await pool.query(`
      SELECT \`Personal _ID\`, COALESCE(Forenames, 'Unknown') as Forenames, COALESCE(Surname, 'Unknown') as Surname 
      FROM \`familytree_people\`
    `);
    
    // Create a map for quick lookup of person names by ID
    const peopleMap = new Map();
    peopleRows.forEach(person => {
      const name = `${person.Forenames} ${person.Surname}`.trim();
      peopleMap.set(person['Personal _ID'], name || 'Unknown');
    });
    
    // Process each family with proper data handling
    const enhancedFamilies = familiesRows.map(family => {
      // Count children and get their names
      const children = [];
      for (let i = 1; i <= 10; i++) {
        const childId = family[`Child_ID_${i}`];
        if (childId && childId.trim() && childId !== 'Unknown') {
          const childName = peopleMap.get(childId.trim()) || childId;
          children.push(childName);
        }
      }
      
      // Ensure Father_Name and Mother_Name are properly set
      let fatherName = family.Father_Name;
      let motherName = family.Mother_Name;
      
      // If Father_Name is Unknown but we have Father ID, try to get name from people table
      if (fatherName === 'Unknown' && family['Father ID'] && family['Father ID'] !== 'Unknown') {
        fatherName = peopleMap.get(family['Father ID']) || 'Unknown';
      }
      
      // If Mother_Name is Unknown but we have Mother ID, try to get name from people table
      if (motherName === 'Unknown' && family['Mother_ID'] && family['Mother_ID'] !== 'Unknown') {
        motherName = peopleMap.get(family['Mother_ID']) || 'Unknown';
      }
      
      return {
        'Family_ID': family.Family_ID,
        'Father ID': family['Father ID'],
        'Mother_ID': family['Mother_ID'],
        'Marriage_Year': family.Marriage_Year_Display,
        'Father_Name': fatherName,
        'Mother_Name': motherName,
        'Marriage_Year_Display': family.Marriage_Year_Display,
        'Children_Count': children.length,
        'Children_Names': children
      };
    });
    
    res.json(enhancedFamilies);
  } catch (err) {
    console.error('Enhanced families endpoint error:', err);
    res.status(500).json({ error: 'Database error' });
  }
});

module.exports = router;
